
<template>
  <h3>WiFi连接情况</h3>
  <a-list item-layout="horizontal" :data-source="wifiData">
    <template #renderItem="{ item }">
      <a-list-item>
        <a-list-item-meta
          description="Ant Design, a design language for background applications, is refined by Ant UED Team"
        >
          <template #title>
            <a>{{ item.title }}</a>
          </template>
          <template #avatar>
            <a-avatar src="https://joeschmoe.io/api/v1/random" />
          </template>
        </a-list-item-meta>
      </a-list-item>
    </template>
  </a-list>
  <h3>设备探测信息</h3>
  <a-list item-layout="horizontal" :data-source="deviceData">
    <template #renderItem="{ item }">
      <a-list-item>
        <a-list-item-meta
          description="Ant Design, a design language for background applications, is refined by Ant UED Team"
        >
          <template #title>
            <a>{{ item.title }}</a>
          </template>
          <template #avatar>
            <a-avatar src="https://joeschmoe.io/api/v1/random" />
          </template>
        </a-list-item-meta>
      </a-list-item>
    </template>
  </a-list>
</template>

<script setup lang="ts">
//内容中参数配置固定栏
interface DataItem {
  title: string;
}
const wifiData: DataItem[] = [
  {
    title: 'WiFi连接情况',
  }
];
const deviceData: DataItem[] = [
  {
    title: '设备1',
  },
  {
    title: '设备2',
  },
];
</script>

<style scoped>

</style>
