<template>
  <div id="TrafficDisplay" :style="{ padding: '24px 0' }">

    <TheWelcome />
  </div>
</template>

<script setup lang="ts">

import TheWelcome from '@/components/TheWelcome.vue'
</script>
<style scoped>

</style>
