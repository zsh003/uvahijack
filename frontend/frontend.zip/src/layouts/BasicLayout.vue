<template>
  <div id="BasicLayout">
    <a-layout>
      <!--- 顶部导航栏 --->
      <a-layout-header class="header">
        <div class="logo" >
          无人机的通信安全劫持系统
        </div>
        <a-menu
          class="menu"
          v-model:selectedKeys="selectedKeys1"
          theme="dark"
          mode="horizontal"
          :style="{ lineHeight: '64px', padding:'0 128px'}"
          :items="items"
          @click="doMenuClick"
        />

      </a-layout-header>

      <!--- 导航栏以下的内容 --->
      <a-layout class="wrapper">
        <!--- 小导航+侧边栏+内容部分 --->
        <a-layout-content class="container">
          <!--- 小导航 --->
          <a-breadcrumb style="margin: 16px 0">
            <a-breadcrumb-item>Home</a-breadcrumb-item>
            <a-breadcrumb-item>List</a-breadcrumb-item>
            <a-breadcrumb-item>App</a-breadcrumb-item>
          </a-breadcrumb>

          <a-layout class="content-wrapper">
            <!--- 侧边栏 --->
            <a-layout-sider width="250" style="background: #fff">
              <a-menu
                v-model:selectedKeys="selectedKeys2"
                v-model:openKeys="openKeys"
                mode="inline"
                :style="{height: '100%'}"
              >
                <a-menu-item key="1">
                  <span>
                    <laptop-outlined />
                    WiFi连接
                  </span>
                </a-menu-item>

                <a-menu-item key="2">
                  <span>
                    <laptop-outlined />
                    设备探测
                  </span>
                </a-menu-item>

                <a-sub-menu key="sub1">
                  <template #title>
                    <span>
                      <laptop-outlined />
                      重放攻击劫持
                    </span>
                  </template>
                  <a-menu-item key="3">油门启动劫持</a-menu-item>
                  <a-menu-item key="4">油门关闭劫持</a-menu-item>
                  <a-menu-item key="5">起飞劫持</a-menu-item>
                  <a-menu-item key="6">转向劫持</a-menu-item>
                </a-sub-menu>

                <a-sub-menu key="sub2">
                  <template #title>
                    <span>
                      <laptop-outlined />
                      DDoS攻击劫持
                    </span>
                  </template>
                  <a-menu-item key="7">TCP泛洪</a-menu-item>
                  <a-menu-item key="8">UDP泛洪</a-menu-item>
                </a-sub-menu>

              </a-menu>
            </a-layout-sider>
            <!--- 内容部分 --->
            <div class="container-content" :style="{ padding: '0 24px'}">
              <!--- ip mac等参数，不随着router-view变化 --->
              <div class="config-section" :style="{ padding: '24px', backgroundColor: '#f0f2f5' }">
                <DeviceDisplay/>
              </div>
              <!--- 通过RouterView组件(配置：router/index.ts)动态替换页面内容 很重要！--->
              <a-layout-content :style="{ padding: '0 24px', minHeight: '280px' }">
                <router-view/>
              </a-layout-content>
            </div>
          </a-layout>

        </a-layout-content>
        <!--- 底部栏 --->
        <a-layout-footer class="footer">
          20211631单凯
        </a-layout-footer>
      </a-layout>

    </a-layout>
  </div>
</template>

<script setup lang="ts">
// 导入页面
import DeviceDisplay from '@/views/DeviceDisplay.vue'

// 导航栏设置
import { MailOutlined, AppstoreOutlined, SettingOutlined } from '@ant-design/icons-vue';
import type { MenuProps } from 'ant-design-vue'
import { useRouter } from 'vue-router'
import { h, ref } from 'vue';

const items = ref<MenuProps['items']>([
  {
    key: '/TransAttack',
    icon: () => h(AppstoreOutlined),
    label: '通信攻击劫持展示',
    title: '通信攻击劫持展示',
  },
  {
    key: '/CustomAttack',
    icon: () => h(MailOutlined),
    label: '自定义流量劫持设置',
    title: '自定义流量劫持设置',
  },
]);
const router = useRouter();  //导航栏路由跳转
const selectedKeys1 = ref<string[]>(['/TransAttack']);
router.afterEach((to, from, next) => {
  selectedKeys1.value = [to.path]
});
const doMenuClick = ({ key }: {key: string}) => {
  router.push({
    path: key,
    //query: { key } //路由跳转参数
  });
}

//左侧菜单栏设置
import { UserOutlined, LaptopOutlined, NotificationOutlined } from '@ant-design/icons-vue'
const selectedKeys2 = ref<string[]>(['1'])
const openKeys = ref<string[]>(['sub1'])


</script>

<style scoped>
/* 最上面大logo */
.header .logo {
  float: left;
  /* 让背景比文字更宽 */
  padding: 0 40px; /* 左右各增加40px的内边距 */
  height: 64px; /* 匹配布局的高度 */
  margin: 0 24px 0 0; /* 调整外边距 */
  background: rgba(255, 255, 255, 0.3);
  color: #fff;
  font-size: 20px;
  line-height: 64px; /* 文本垂直居中 */
  white-space: nowrap;   /* 文字不换行显示 */
  min-width: 200px; /* 设置最小宽度以确保背景足够宽 */
  box-sizing: border-box; /* 确保内边距和边框包含在元素的宽度和高度之内 */
}
.header .menu {

}

/* 包装导航栏以下的内容（小导航+侧边栏+内容部分+底部栏） */
.wrapper{
  padding: 8px 0;
  background: #f8f8f8;
  min-height: 100vh; /* 设置最小高度为视口高度 很重要*/
}
/* 小导航+侧边栏+内容部分 */
.container{
  padding: 0 50px;
}

/* 包装侧边栏+内容部分 */
.content-wrapper{
  padding: 24px 0;
  background: #fff;
  min-height: 80vh;
}

/*内容部分中固定栏+动态内容*/
.container-content {
  display: flex;
  flex-direction: column;  /*固定栏和动态内容是上下or左右分布*/
}
/*参数配置固定栏*/
.config-section {
  border-bottom: 1px solid #e8e8e8;
}

/* 底部栏 */
.footer{
  background: #f8f8f8;
  text-align: center;
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  padding: 12px;
}
</style>
