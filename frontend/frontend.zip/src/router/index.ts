import { createRouter, createWebHistory } from 'vue-router'
import TransAttack from '../views/TransAttack.vue'
import CustomAttack from '../views/CustomAttack.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/TransAttack',
      name: 'transmission attack',
      component: TransAttack,
    },
    {
      path: '/CustomAttack',
      name: 'custom attack',
      component: CustomAttack,
    },
  ],
})

export default router
